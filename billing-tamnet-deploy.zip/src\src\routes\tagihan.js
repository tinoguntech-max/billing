const router = require('express').Router()
const pool   = require('../db')

router.get('/', async (req, res) => {
  try {
    const { status = '', id_pelanggan = '', search = '', sortBy = 'created_at', sortOrder = 'desc', page = 1, limit = 10 } = req.query
    const pg  = Math.max(1, Number(page))
    const lim = Math.min(100, Number(limit))
    const off = (pg - 1) * lim

    const allowedSort = { created_at: 't.created_at', no_tagihan: 't.no_tagihan', nama_pelanggan: 'p.nama', jumlah: 't.jumlah', tgl_jatuh_tempo: 't.tgl_jatuh_tempo', status: 't.status', periode: 't.periode' }
    const orderCol = allowedSort[sortBy] || 't.created_at'
    const orderDir = sortOrder === 'asc' ? 'ASC' : 'DESC'

    let where = 'WHERE 1=1'
    const params = []
    if (status === 'Terlambat') {
      where += " AND t.status='Belum Bayar' AND t.tgl_jatuh_tempo < CURDATE()"
    } else if (status) {
      where += ' AND t.status=?'; params.push(status)
    }
    if (id_pelanggan) { where += ' AND t.id_pelanggan=?';  params.push(id_pelanggan) }
    if (search)       { where += ' AND (p.nama LIKE ? OR t.no_tagihan LIKE ?)'; params.push(`%${search}%`, `%${search}%`) }

    const [[countRows], [rows], [summaryRows], [terlambatRows], [bulanIniRows], [lunasBulanIniRows]] = await Promise.all([
      pool.query(`SELECT COUNT(*) AS total FROM tagihan t JOIN pelanggan p ON t.id_pelanggan=p.id ${where}`, params),
      pool.query(`SELECT t.*, p.nama AS nama_pelanggan, pk.nama_paket, pk.kecepatan
                  FROM tagihan t
                  JOIN pelanggan p ON t.id_pelanggan=p.id
                  LEFT JOIN paket pk ON p.id_paket=pk.id
                  ${where} ORDER BY ${orderCol} ${orderDir} LIMIT ? OFFSET ?`, [...params, lim, off]),
      pool.query(`SELECT t.status, COUNT(*) AS count, COALESCE(SUM(t.jumlah),0) AS nominal
                  FROM tagihan t JOIN pelanggan p ON t.id_pelanggan=p.id
                  ${where} GROUP BY t.status`, params),
      pool.query(`SELECT COUNT(*) AS count, COALESCE(SUM(t.jumlah),0) AS nominal
                  FROM tagihan t JOIN pelanggan p ON t.id_pelanggan=p.id
                  WHERE t.status='Belum Bayar' AND t.tgl_jatuh_tempo < CURDATE()`),
      pool.query(`SELECT COUNT(*) AS count, COALESCE(SUM(t.jumlah),0) AS nominal
                  FROM tagihan t
                  WHERE MONTH(t.created_at)=MONTH(CURDATE()) AND YEAR(t.created_at)=YEAR(CURDATE())`),
      pool.query(`SELECT COUNT(*) AS count, COALESCE(SUM(t.jumlah),0) AS nominal
                  FROM tagihan t
                  JOIN pembayaran py ON py.id_tagihan = t.id
                  WHERE t.status='Lunas'
                    AND MONTH(py.tgl_bayar)=MONTH(CURDATE()) AND YEAR(py.tgl_bayar)=YEAR(CURDATE())`),
    ])
    const totalCount = Number(countRows[0].total)
    const summaryMap = {}
    summaryRows.forEach(s => { summaryMap[s.status] = { count: Number(s.count), nominal: Number(s.nominal) } })
    summaryMap['Terlambat'] = { count: Number(terlambatRows[0].count), nominal: Number(terlambatRows[0].nominal) }
    summaryMap['BulanIni']       = { count: Number(bulanIniRows[0].count), nominal: Number(bulanIniRows[0].nominal) }
    summaryMap['LunasBulanIni']  = { count: Number(lunasBulanIniRows[0].count), nominal: Number(lunasBulanIniRows[0].nominal) }
    res.json({ data: rows, total: totalCount, page: pg, limit: lim, summary: summaryMap })
  } catch (e) { res.status(500).json({ error: e.message }) }
})

router.post('/', async (req, res) => {
  try {
    const { id_pelanggan, periode, jumlah, tgl_jatuh_tempo } = req.body
    if (!id_pelanggan || !jumlah) return res.status(400).json({ error: 'id_pelanggan dan jumlah wajib diisi' })

    const now = new Date()
    const yy  = String(now.getFullYear()).slice(2)
    const mm  = String(now.getMonth() + 1).padStart(2, '0')
    const [[{ c }]] = await pool.query('SELECT COUNT(*) AS c FROM tagihan')
    const no_tagihan = `INV-${yy}${mm}-${String(c + 1).padStart(3, '0')}`

    const [r] = await pool.query(
      `INSERT INTO tagihan (no_tagihan,id_pelanggan,periode,jumlah,tgl_jatuh_tempo,status)
       VALUES (?,?,?,?,?,'Belum Bayar')`,
      [no_tagihan, id_pelanggan, periode, jumlah, tgl_jatuh_tempo]
    )
    res.status(201).json({ id: r.insertId, no_tagihan })
  } catch (e) { res.status(500).json({ error: e.message }) }
})

router.put('/:id', async (req, res) => {
  try {
    const { status } = req.body
    await pool.query('UPDATE tagihan SET status=? WHERE id=?', [status, req.params.id])
    res.json({ message: 'Tagihan diperbarui' })
  } catch (e) { res.status(500).json({ error: e.message }) }
})

router.delete('/:id', async (req, res) => {
  try {
    await pool.query('DELETE FROM tagihan WHERE id=?', [req.params.id])
    res.json({ message: 'Tagihan dihapus' })
  } catch (e) { res.status(500).json({ error: e.message }) }
})

// Generate otomatis — batch insert, no N+1
router.post('/generate-otomatis', async (req, res) => {
  try {
    const today        = new Date()
    const currentMonth = today.getMonth() + 1
    const currentYear  = today.getFullYear()
    const mmyy         = `${String(currentMonth).padStart(2,'0')}${currentYear}`
    const periode      = new Intl.DateTimeFormat('id-ID', { year:'numeric', month:'long' }).format(today)

    const [pelanggan] = await pool.query(`
      SELECT p.id, p.nama, p.tgl_bergabung, pk.harga
      FROM pelanggan p JOIN paket pk ON p.id_paket=pk.id
      WHERE p.status='Aktif' AND p.tgl_bergabung IS NOT NULL
        AND p.id NOT IN (
          SELECT id_pelanggan FROM tagihan
          WHERE periode=?
        )
    `, [periode])

    if (!pelanggan.length) return res.json({ success: true, message: '0 tagihan dibuat (semua sudah ada)', created: 0 })

    const [[{ count }]] = await pool.query(
      'SELECT COUNT(*) AS count FROM tagihan WHERE MONTH(created_at)=? AND YEAR(created_at)=?',
      [currentMonth, currentYear]
    )

    const placeholders = []
    const values = []
    const periodeGenerate = new Intl.DateTimeFormat('id-ID', { year:'numeric', month:'long' }).format(today)

    pelanggan.forEach((p, i) => {
      const tglBergabung = new Date(p.tgl_bergabung)
      const tanggal      = tglBergabung.getDate()
      // Jatuh tempo = tanggal bergabung + 3 hari, tapi tetap di bulan yang sama
      const lastDayOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate()
      const tglJatuhTempo  = Math.min(tanggal + 3, lastDayOfMonth)
      const jatuhTempo     = new Date(today.getFullYear(), today.getMonth(), tglJatuhTempo)

      const noTagihan = `INV-${mmyy}-${String(Number(count) + i + 1).padStart(3,'0')}`
      placeholders.push('(?,?,?,?,?,?)')
      values.push(noTagihan, p.id, periodeGenerate, p.harga, jatuhTempo.toISOString().split('T')[0], 'Belum Bayar')
    })

    await pool.query(
      `INSERT INTO tagihan (no_tagihan,id_pelanggan,periode,jumlah,tgl_jatuh_tempo,status) VALUES ${placeholders.join(',')}`,
      values
    )
    res.status(201).json({ success: true, message: `${pelanggan.length} tagihan berhasil dibuat`, created: pelanggan.length })
  } catch (e) { res.status(500).json({ error: e.message }) }
})

module.exports = router
